// pages/Traffic/Traffic.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    markers: [{
      iconPath: "../img/11.png",
      id: 0,
      latitude: 39.904030077901037,
      longitude: 116.40752599999995,
      width: 15,
      height: 15
    }],
    polyline: [{
      points: [
        {
          longitude: 116.40752599999995,
          latitude: 39.904030077901037
        },
        {
          longitude: 116.40752599999995,
          latitude: 39.904030077901037
        }
      ],
      color: "#E4393c",
      width: 2,
      dottedLine: true
    }],
    controls: [{
      id: 1,
      iconPath: '../img/22.png',
      position: {
        left: 0,
        top: 300 - 50,
        width: 5,
        height: 5
      },
      clickable: true
    }]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        wx.openLocation({
          latitude: latitude,
          longitude: longitude,
          scale: 28
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})