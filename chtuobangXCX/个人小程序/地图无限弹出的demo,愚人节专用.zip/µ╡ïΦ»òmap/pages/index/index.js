//index.js
//获取应用实例
var QQMapWX = require('../libs/qqmap-wx-jssdk.js');
var qqmapsdk;
var app = getApp()
Page({
  data: {
    lat:"",
    long:"",
    star:"",
    name:"",
   
  },
 //以下定义方法
 selected:function(){
   wx.navigateTo({
     url: '../selectlocation/selectlocation'
   })
 },
 tar:function(){
   console.log("点击了查看路况");
   wx.navigateTo({
     url: '../Traffic/Traffic?start=' + this.data.star + '&end=' + this.data.name
   })
 },
  // address:function(e){
  //     console.log(e)
  // },
  // regionchange(e) {
  //   console.log(e.type)
  // },
  // markertap(e) {
  //   console.log(e.markerId)
  // },
  // controltap(e) {
  //   console.log(e.controlId)
  // },
  onLoad: function (res) {
    console.log(res.name)
    var that=this;
    that.setData({
      name:res.name
    })
  // 实例化API核心类
  console.log("onload");
 qqmapsdk = new QQMapWX({
      key: 'SFHBZ-3IUK4-EMAUV-DBVJA-SSHTQ-EHBOO'
    });
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        console.log("获取当前的location")
        console.log(res)
        var latitude = res.latitude
        var longitude = res.longitude
        that.setData({
          lat: latitude,
          long: longitude
        })
        console.log(that.data.lat)
        // wx.openLocation({
        //   latitude: latitude,
        //   longitude: longitude,
        //   scale: 18
        // })
        qqmapsdk.reverseGeocoder({
          location: {
            latitude: that.data.lat,
            longitude: that.data.long
          },
          success: function (res) {
            console.log('坐标位置描述')
            console.log("您当前位置在"+res.result.address); 
            that.setData({
              star: res.result.address
            })
          },
          fail: function (res) {
            console.log(res);
          },
          complete: function (res) {
            console.log(res);
          }
        });
      }
    })

  },
  onShow: function () {
    var that=this;
    console.log("onshow")

    //获取到当前的位置，把坐标转换为地址
    //坐标位置描述-逆地址解析
   
    



    // 调用地点搜索，返回当前关键字的附近相同场所
    // qqmapsdk.search({
    //   keyword: '酒店',
    //   success: function (res) {
    //     console.log("酒店")
    //     console.log(res);
    //   },
    //   fail: function (res) {
    //     console.log(res);
    //   },
    //   complete: function (res) {
    //     console.log(res);
    //   }
    // });
    
    // qqmapsdk.geocoder({
    //   address: '北京市朝阳区安家楼路燕莎50号院A3车托帮',
    //   success: function (res) {
    //     console.log("地址转坐标")
    //     console.log(res);
    //   },
    //   fail: function (res) {
    //     console.log(res);
    //   },
    //   complete: function (res) {
    //     console.log(res);
    //   }
    // });
//关键词补全
    // qqmapsdk.getSuggestion({
    //   keyword: '技术',
    //   success: function (res) {
    //     console.log("关键词补全");
    //     console.log(res);
    //   },
    //   fail: function (res) {
    //     console.log(res);
    //   },
    //   complete: function (res) {
    //     console.log(res);
    //   }
    // });

    // 距离计算
    // qqmapsdk.calculateDistance({
    //   to: [{
    //     latitude:    39.904030077901037,
    //     longitude:     116.40752599999995
    //   }, {
    //       latitude:    39.95510,
    //       longitude:    116.47800
    //   }],
    //   success: function (res) {
    //     console.log("距离计算")
    //     console.log(res);
    //   },
    //   fail: function (res) {
    //     console.log(res);
    //   },
    //   complete: function (res) {
    //     console.log(res);
    //   }
    // });

    // 获取城市列表
    // qqmapsdk.getCityList({
    //   success: function (res) {
    //     console.log("获取城市列表")
    //     console.log(res);
    //   },
    //   fail: function (res) {
    //     console.log(res);
    //   },
    //   complete: function (res) {
    //     console.log(res);
    //   }
    // });

    // 获取区县
    // qqmapsdk.getDistrictByCityId({
    //   id: '110000', // 对应城市ID
    //   success: function (res) {
    //     console.log("获取区县")
    //     console.log(res);
    //   },
    //   fail: function (res) {
    //     console.log(res);
    //   },
    //   complete: function (res) {
    //     console.log(res);
    //   }
    // });

  }
  });